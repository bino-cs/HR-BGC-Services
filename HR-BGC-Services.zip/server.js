const express=require('express');
const bodyParser=require('body-parser');
const cors = require("cors");
const morgan = require("morgan");
const mongojs = require("mongojs");
const jwt = require("jsonwebtoken");

const educationRoutes = require("./routes/education.route");
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cors());
app.use(morgan("dev"));

app.use("/api/education", educationRoutes);
app.use("/api/education", educationRoutes);



app.listen(3000, () => {
    console.log("Server is listening on port 3000");
});