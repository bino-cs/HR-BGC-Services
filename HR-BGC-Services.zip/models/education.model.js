// const mongoose = require('mongoose');
// const Schema = mongoose.Schema;

// let EducationSchema = new Schema({
//     startDate: {type: String, required: true, max: 100},
//     endDate: {type: String, required: true, max: 100},
//     institutionName:{type: String, required: true, max: 100},
//     universityName:{type: String, required: true, max: 100},
//     certificatePath:{type: String, required: true, max: 100}
// });

// module.exports = mongoose.model('education', EducationSchema,'Education');