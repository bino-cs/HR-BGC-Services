const express = require('express');
const educationRouter = express.Router();

// Require the controllers WHICH WE DID NOT CREATE YET!!
const educationController = require('../controllers/education.controller');


educationRouter.get("/", (request, response) => {
    let events = educationController.getAllEducationDetails();
    events.then(
        data => response.json(data),
        reason => response.json(reason)
    );
});




// a simple test url to check that all of our files are communicating correctly.
// router.get('/getEducation', educationController.getEducation);
// router.post('/create',educationController.create);

module.exports = educationRouter;