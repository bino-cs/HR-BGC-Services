const express = require('express');
const workRouter = express.Router();

// Require the controllers WHICH WE DID NOT CREATE YET!!
const workController = require('../controllers/work.controller');


workRouter.get("/", (request, response) => {
    let events = workController.getAllWorkDetails();
    events.then(
        data => response.json(data),
        reason => response.json(reason)
    );
});

workRouter.post("/", (request, response) => {
    let WorkDetails = request.body;
    console.log(WorkDetails);
    let workPromise = workController.saveWorkDetails(WorkDetails);
    workPromise.then(
        data => response.json(data),
        reason => response.json(reason)
    );
});

module.exports=workRouter;