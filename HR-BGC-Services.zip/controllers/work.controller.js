const mongojs = require("mongojs");
const db = mongojs("HRBGC", ["WorkDetails"]);

class WorkController {

    getAllWorkDetails() {
        return new Promise((resolve, reject) => {
            db.WorkDetails.find((err, docs) => {
                if (err) {
                    reject(err)
                }
                resolve(docs)
            });
        });
    }
    saveWorkDetails(work) {
        let newWork = { ...work };
        return new Promise((resolve, reject) => {
            db.WorkDetails.insert(newWork, (err, doc) => {
                if (err) {
                    reject(err)
                }
                resolve(doc);
                
            });
        });
    }
}

module.exports = new WorkController;
