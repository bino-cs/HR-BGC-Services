const mongojs = require("mongojs");
const db = mongojs("HRBGC", ["Education"]);

//Simple version, without validation or sanitation
class EducationController {

    getAllEducationDetails() {

        return new Promise((resolve, reject) => {
            db.Education.find((err, docs) => {
                if (err) {
                    reject(err);
                }
                resolve(docs);
            });
        });
    };

    saveAllEducationDetails(education) {
        let newEducation = {
            ...education           
        };
        return new Promise((resolve, reject) => {
            db.Education.insert(newEducation, (err, doc) => {
                if (err) { reject(err) }
                resolve(doc)
            })
        })
    };

    // exports.saveAllEducationDetails = function (req, res) {
    //     let education = new Education(
    //         {
    //             startDate: req.body.startDate,
    //             endDate: req.body.endDate,
    //             institutionName: req.body.institutionName,
    //             universityName: req.body.universityName,
    //             certificatePath: req.body.certificatePath
    //         });

    //     education.save(function (err) {
    //         if (err) {
    //             return next(err);
    //         }
    //         res.send('Education Created successfully');
    //     });
    // }
}
module.exports =new EducationController()