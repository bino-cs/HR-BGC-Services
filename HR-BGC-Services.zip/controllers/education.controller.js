// const Education = require('../models/education.model');
const mongojs = require("mongojs");
const db = mongojs("HRBGC", ["Education"]);

//var mongojs = require('mongojs');
//var db = mongojs('HRBGC', ['Personal']);

//Simple version, without validation or sanitation
exports.getAllEducationDetails = function (req, res) {

 return new Promise((resolve, reject) => {
            db.Education.find((err, docs) => {
                if (err) {
                    reject(err);
                }
                resolve(docs);
            });
        });
};

// exports.create = function (req, res) {
//     let education = new Education(
//         {
//             startDate: req.body.startDate,
//             endDate: req.body.endDate,
//             institutionName: req.body.institutionName,
//             universityName: req.body.universityName,
//             certificatePath: req.body.certificatePath
//         });

//     education.save(function (err) {
//         if (err) {
//             return next(err);
//         }
//         res.send('Education Created successfully');
//     });
// }