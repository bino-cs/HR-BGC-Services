const Personal = require('../models/employee.model');
//var mongojs = require('mongojs');
//var db = mongojs('HRBGC', ['Personal']);

//Simple version, without validation or sanitation
exports.getEmployees = function (req, res) {
    res.send('Greetings from the Test controller from employee');
};

exports.create = function (req, res) {
    let employee = new Personal(
        {
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            email: req.body.email
        });
    employee.save(function (err) {
        if (err) {
            return next(err);
        }
        res.send('Employee Created successfully')
    });
}

